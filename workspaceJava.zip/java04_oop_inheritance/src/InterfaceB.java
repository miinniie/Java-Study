
public interface InterfaceB {
	public void multiple();
}
