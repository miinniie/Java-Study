
public interface InterfaceA {
	public int getData();
	
}
