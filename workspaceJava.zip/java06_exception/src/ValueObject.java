
public class ValueObject {

	public static void main(String[] args) {

	}
}
