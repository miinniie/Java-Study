
public class MemberTest {

	public static void main(String[] args) {
		
		Member m1 = new Member();
		Member m2 = new Member(5,"ȫ","����");
		Member m3 = new Member(200,"��","����");
		
		
		
	}

}
