
public class GuGuDanMain {
	
	public static void main(String[] args) {
		GuGuDan gugu = new GuGuDan();
		gugu.allGugudan();
		gugu.gugudan(10);
	
		int d = gugu.consoleInput("�����Է��ϼ���..");
		gugu.gugudan(d);
		
	}
}
