
public class CalendarObjectMain {

	public static void main(String[] args) {
		
		CalendarObject co = new CalendarObject();
//		co.myCalendar();
		
		
//		CalendarObject calen = new CalendarObject();	
//		int year = calen.consoleInputYear("����");
//		int month = calen.consoleInputYear("��");
//		
//		int lastDay = calen.switchToDayInMonth(year, month);
//		int week = calen.Week(year, month);
//
//		calen.printTop(year,month);
//		calen.printAll(week,lastDay);
//		
	}
}
