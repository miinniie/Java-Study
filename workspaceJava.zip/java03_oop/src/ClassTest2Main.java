
public class ClassTest2Main {

	public static void main(String[] args) {
		ClassTest2 ct = new ClassTest2();
		ct.sum();
		ClassTest2 ct2 = new ClassTest2(100);
		ct2.sum();
		ClassTest2 ct3 = new ClassTest2(200, "ȫ�浿");
		ct3.sum();
		
		
	}
}
