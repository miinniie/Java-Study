
public class ForTest {

	public static void main(String[] args) {
		for(int i=10; i>=1; i-=1) {
			System.out.println(i);
		}
	}

}
