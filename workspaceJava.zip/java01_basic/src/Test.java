class Test{
	public static void main(String args[ ]){
		System.out.println("start~~~~~~");
		System.out.println("�ѱ�Ȯ��");
		int j=100;
	}
}

class mihn{
	public static void main(String[] args) {
	print
	}n 
}