
public class WhileTest1 {

	public static void main(String[] args) {
		int i=0;
		while(i<=5) {
			i++;
			System.out.println(i);
		}
		
		System.out.println("=====================");
		int j = 1;
		while(j<=5) {
			int k=1;
			while(k<=5) {
				System.out.print(k);
				k++;
			}
			System.out.println();
			j++;
		}
	
	
	
	
	}

}
