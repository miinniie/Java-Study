
public class algo {

	public static void main(String[] args) {
		String str = "951128-2345678";
		System.out.println(str.substring(6,6));
		
	}
}

