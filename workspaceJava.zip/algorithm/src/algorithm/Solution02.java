package algorithm;

import java.util.Scanner;

public class Solution02 {

	public Solution02() {
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		
		for(int i; i<= cnt)
			
		int intArr[] = Array.stream(s.nextLine().split(" ")).mapToInt
	}

}
