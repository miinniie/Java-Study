
class Aclass{}
class Bclass extends Aclass{}
class Ccclass extends Aclass{}

Aclass p0 = new Aclass();
Bclass p1 = new Bcalss();
Cclass p2 = new Cclass();
Aclass p3 = new Bclass;
Aclass p4 = new Cclass():