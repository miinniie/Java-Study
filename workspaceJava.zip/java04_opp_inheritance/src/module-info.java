module java04_opp_inheritance {
}