package java04_opp_inheritance;

public class Car {

}
