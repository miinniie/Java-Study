
public class AAA {
	public AAA() {}
	public MemberVO memberList() {
		//�����Ͱ� �߻��Ѱ�
		int num = 250;
		String name = "�̼���";
		String tel = "010-1234-5678";
		
		MemberVO vo = new MemberVO();
		vo.setNum(num);
		vo.setUserName(name);
		vo.setTel(tel);
		
		
		
	}
	
	
	
	
}
