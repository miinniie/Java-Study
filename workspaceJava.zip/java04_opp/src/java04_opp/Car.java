package java04_opp;

public class Car {

}
